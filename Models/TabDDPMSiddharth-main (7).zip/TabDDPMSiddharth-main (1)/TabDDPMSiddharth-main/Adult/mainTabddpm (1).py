#!/usr/bin/env python
import os
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import math
import warnings

# For TSTR evaluation
from sklearn.metrics import accuracy_score
# from sklearn.model_selection import train_test_split # Not used in this specific TSTR setup
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression # <-- Added Logistic Regression
import xgboost as xgb

# Optional: Suppress potential UserWarning from XGBoost regarding label encoding
warnings.filterwarnings("ignore", category=UserWarning, module='xgboost')
# Optional: Suppress convergence warnings from Logistic Regression if needed
from sklearn.exceptions import ConvergenceWarning
warnings.filterwarnings("ignore", category=ConvergenceWarning, module='sklearn')

# -------------------------------
# Define Time Embedding Module
# -------------------------------
class SinusoidalPosEmb(nn.Module):
    """
    Creates sinusoidal positional embeddings for the timestep 't'.
    """
    def __init__(self, dim):
        super().__init__()
        self.dim = dim # The dimension of the embedding vector

    def forward(self, time):
        """
        Args:
            time (torch.Tensor): A 1D tensor of timesteps, shape (batch_size,)
        Returns:
            torch.Tensor: Positional embeddings, shape (batch_size, dim)
        """
        device = time.device
        half_dim = self.dim // 2
        # Calculate embedding frequencies (denominator term)
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        # Calculate embedding arguments (time * frequency)
        embeddings = time[:, None] * embeddings[None, :]
        # Apply sin and cos
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        # Handle odd dimensions if necessary (though usually dim is even)
        if self.dim % 2 == 1:
            embeddings = torch.cat([embeddings, torch.zeros_like(embeddings[:, :1])], dim=-1)
        return embeddings

# -------------------------------
# Define Residual Block Module
# -------------------------------
class ResidualBlock(nn.Module):
    """
    A residual block with Layer Normalization and SiLU activation.
    """
    def __init__(self, dim):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.act1 = nn.SiLU() # SiLU (Swish) often works well
        self.linear1 = nn.Linear(dim, dim)
        self.norm2 = nn.LayerNorm(dim)
        self.act2 = nn.SiLU()
        self.linear2 = nn.Linear(dim, dim)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor, shape (batch_size, dim)
        Returns:
            torch.Tensor: Output tensor, shape (batch_size, dim)
        """
        residual = x
        out = self.norm1(x)
        out = self.act1(out)
        out = self.linear1(out)
        out = self.norm2(out)
        out = self.act2(out)
        out = self.linear2(out)
        # Add the residual connection
        out = out + residual
        return out

# -------------------------------
# Define the Complex MLP model for diffusion (TabDDPM)
# -------------------------------
class ComplexMLP(nn.Module):
    """
    A more complex MLP incorporating time embeddings and residual blocks
    to predict the noise added to data in a diffusion process.
    """
    def __init__(self, input_dim, hidden_dim, num_residual_blocks, time_emb_dim):
        """
        Args:
            input_dim (int): Dimension of the input data (number of features).
            hidden_dim (int): Hidden dimension used throughout the network.
            num_residual_blocks (int): Number of residual blocks to stack.
            time_emb_dim (int): Dimension for the sinusoidal time embedding.
        """
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.time_emb_dim = time_emb_dim

        # --- Time Embedding Layers ---
        self.time_embedding = SinusoidalPosEmb(time_emb_dim)
        # MLP to project time embedding to the main hidden dimension
        self.time_mlp = nn.Sequential(
            nn.Linear(time_emb_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )

        # --- Main Network Layers ---
        # Initial projection of the input data x_t
        self.input_proj = nn.Linear(input_dim, hidden_dim)

        # Stack of residual blocks
        self.residual_blocks = nn.ModuleList([
            ResidualBlock(hidden_dim) for _ in range(num_residual_blocks)
        ])

        # Final projection layer to predict noise (output dim = input dim)
        self.final_proj = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x_t, t):
        """
        Forward pass through the network.

        Args:
            x_t (torch.Tensor): Noisy input data at timestep t, shape (batch_size, input_dim).
            t (torch.Tensor): Timesteps for each sample in the batch, shape (batch_size,).

        Returns:
            torch.Tensor: Predicted noise (epsilon), shape (batch_size, input_dim).
        """
        # 1. Compute time embedding and project it
        time_emb = self.time_embedding(t) # (batch_size, time_emb_dim)
        time_emb = self.time_mlp(time_emb) # (batch_size, hidden_dim)

        # 2. Project input data
        x_proj = self.input_proj(x_t) # (batch_size, hidden_dim)

        # 3. Combine input projection with time embedding
        h = x_proj + time_emb # Broadcasting adds time_emb

        # 4. Pass through residual blocks
        for block in self.residual_blocks:
            h = block(h) # (batch_size, hidden_dim)

        # 5. Final projection to output dimension
        output = self.final_proj(h) # (batch_size, input_dim)

        return output


# -------------------------------
# Diffusion schedule helper function
# -------------------------------
def get_alpha_bar(T, beta_start, beta_end, device):
    """
    Compute a linear beta schedule,
    alphas = 1 - betas,
    and alpha_bar = cumulative product of alphas.
    """
    betas = torch.linspace(beta_start, beta_end, T, device=device)
    alphas = 1.0 - betas
    alpha_bar = torch.cumprod(alphas, dim=0)
    return betas, alphas, alpha_bar


# -------------------------------
# Training function for TabDDPM on the real dataset
# -------------------------------
def train_tabddpm(data_tensor, hparams, device):
    """
    Trains the TabDDPM (diffusion model using ComplexMLP) on the entire data_tensor.
    data_tensor should be of shape [num_samples, num_features].
    """
    dataset = TensorDataset(data_tensor)
    # Consider enabling pin_memory=True if using GPU and data fits in memory
    # Adjust num_workers based on your system
    dataloader = DataLoader(dataset, batch_size=hparams.batch_size, shuffle=True,
                            num_workers=min(4, os.cpu_count() if os.cpu_count() else 1),
                            pin_memory=torch.cuda.is_available())


    T = hparams.T  # total diffusion timesteps
    betas, alphas, alpha_bar = get_alpha_bar(T, hparams.beta_start, hparams.beta_end, device)

    input_dim = data_tensor.shape[1]
    # Instantiate the ComplexMLP model
    model = ComplexMLP(
        input_dim=input_dim,
        hidden_dim=hparams.hidden_dim,
        num_residual_blocks=hparams.num_residual_blocks,
        time_emb_dim=hparams.time_emb_dim
    ).to(device)

    optimizer = optim.Adam(model.parameters(), lr=hparams.learning_rate)
    num_epochs = hparams.epochs

    print(f"Starting TabDDPM training with ComplexMLP ({hparams.num_residual_blocks} blocks)...")
    for epoch in range(num_epochs):
        running_loss = 0.0
        model.train() # Set model to training mode
        for batch in dataloader:
            x0 = batch[0].to(device)  # clean data sample
            batch_size = x0.shape[0]

            # Sample random timesteps for each sample in batch
            t = torch.randint(0, T, (batch_size,), device=device, dtype=torch.long) # Ensure t is LongTensor

            # Sample Gaussian noise
            epsilon = torch.randn_like(x0)

            # Get corresponding alpha_bar for each sample
            alpha_bar_t = alpha_bar[t].view(batch_size, 1)

            # Forward diffusion: generate x_t = sqrt(alpha_bar_t)*x0 + sqrt(1 - alpha_bar_t)*epsilon
            x_t = torch.sqrt(alpha_bar_t) * x0 + torch.sqrt(1 - alpha_bar_t) * epsilon

            # Predict noise using the model (pass x_t and t separately)
            predicted_epsilon = model(x_t, t)

            # Calculate loss
            loss = F.mse_loss(predicted_epsilon, epsilon)

            # Backpropagation
            optimizer.zero_grad()
            loss.backward()
            # Optional: Gradient clipping (can help stabilize training, especially with deeper networks)
            # torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            running_loss += loss.item() * batch_size

        epoch_loss = running_loss / len(dataset) # Use len(dataset) for exact average
        if (epoch + 1) % 10 == 0 or epoch == 0 or epoch == num_epochs -1: # Print less frequently
             print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {epoch_loss:.6f}")

    print("TabDDPM training complete!")
    # Return the trained model and the diffusion schedule components for sampling.
    return model, T, betas, alphas, alpha_bar


# -------------------------------
# Reverse sampling function for TabDDPM
# -------------------------------
@torch.inference_mode() # More efficient than torch.no_grad() for inference
def sample_tabddpm(model, T, betas, alphas, alpha_bar, num_samples, input_dim, device, batch_size=512):
    """
    Generates synthetic data by starting from pure noise and
    iteratively applying the reverse diffusion process using the ComplexMLP.
    Uses batching for potentially large num_samples.
    Returns a tensor of shape [num_samples, input_dim].
    """
    print(f"Starting sampling for {num_samples} samples using ComplexMLP...")
    model.eval() # Set model to evaluation mode

    all_samples = []
    num_generated = 0
    num_batches = math.ceil(num_samples / batch_size)

    for i in range(num_batches):
        current_batch_size = min(batch_size, num_samples - num_generated)
        print(f"  Generating batch {i+1}/{num_batches} (size {current_batch_size})...")

        # Start from pure Gaussian noise for the current batch
        x = torch.randn(current_batch_size, input_dim, device=device)

        # Iteratively denoise from timestep T-1 to 0.
        for t in reversed(range(T)):
            # Create a tensor of the current timestep t for the batch
            t_tensor = torch.full((current_batch_size,), t, device=device, dtype=torch.long) # Ensure t is LongTensor

            # Predict noise using the model
            predicted_epsilon = model(x, t_tensor)

            # Get schedule parameters for timestep t
            alpha_t = alphas[t]
            alpha_bar_t = alpha_bar[t]
            beta_t = betas[t]
            sqrt_one_minus_alpha_bar_t = torch.sqrt(1.0 - alpha_bar_t)
            sqrt_alpha_t_inv = 1.0 / torch.sqrt(alpha_t)
            beta_t_over_sqrt_one_minus_alpha_bar_t = beta_t / sqrt_one_minus_alpha_bar_t

            # For all but the last step, add additional noise.
            z = torch.randn_like(x) if t > 0 else torch.zeros_like(x)

            # Reverse update rule (DDPM formula)
            x = sqrt_alpha_t_inv * (x - beta_t_over_sqrt_one_minus_alpha_bar_t * predicted_epsilon) \
                + torch.sqrt(beta_t) * z

            # Optional: print progress within a batch for long sampling
            # if t % 200 == 0 and i == 0: # Print only for first batch
            #      print(f"    Batch {i+1} - Timestep {t}/{T}")


        all_samples.append(x.cpu()) # Move generated batch to CPU
        num_generated += current_batch_size

    print("Sampling complete.")
    return torch.cat(all_samples, dim=0) # Concatenate all batches


# -------------------------------
# Function to load real dataset from file
# -------------------------------
def load_dataset(file_path):
    """
    Loads the dataset from file_path.
    Assumes the file is whitespace-delimited and numeric.
    Returns a numpy array.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Dataset file not found: {file_path}")
    print(f"Loading dataset from: {file_path}")
    try:
        # Try loading with space as delimiter first
        try:
             data = np.loadtxt(file_path)
        except ValueError:
             print("Whitespace delimiter failed, trying comma delimiter...")
             # If that fails, try comma delimiter
             data = np.loadtxt(file_path, delimiter=',')

        print(f"Dataset loaded successfully with shape: {data.shape}")
        if data.ndim == 1: # Handle case where loadtxt might return 1D array if file has only one line
             data = data.reshape(1, -1)
        # Check for NaNs or Infs which can cause issues later
        if np.isnan(data).any() or np.isinf(data).any():
            print("Warning: Dataset contains NaN or Inf values. Attempting to replace with 0.")
            data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0) # Replace with 0, or consider other imputation
        return data
    except Exception as e:
        print(f"Error loading dataset from {file_path}: {e}")
        raise


# -------------------------------
# TSTR evaluation: Train on Synthetic, Test on Real (Verbose Version)
# -------------------------------
def tstr_evaluation_cv_full(syn_data, real_data):
    """
    TSTR with 3-Fold CV: Trains classifiers on synthetic data, tests on real data (folded).
    Includes Logistic Regression, MLP, XGBoost, and Random Forest.
    Returns fold-wise accuracy and average accuracy.
    """
    from sklearn.model_selection import KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.neural_network import MLPClassifier
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import accuracy_score
    import xgboost as xgb
    import numpy as np

    def perform_cv_verbose(model, X_real, y_real):
        kf = KFold(n_splits=3, shuffle=True, random_state=42)
        scores = []
        for fold, (_, test) in enumerate(kf.split(X_real), start=1):
            y_pred = model.predict(X_real[test])
            acc = accuracy_score(y_real[test], y_pred)
            scores.append(acc)
            print(f"    Fold {fold} Accuracy: {acc:.4f}")
        avg = np.mean(scores)
        print(f"    Average Accuracy: {avg:.4f}")
        return scores, avg

    if syn_data is None or real_data is None or syn_data.shape[0] == 0 or real_data.shape[0] == 0:
        raise ValueError("Synthetic or real data is empty.")
    if syn_data.shape[1] != real_data.shape[1] or syn_data.shape[1] < 2:
        raise ValueError("Mismatched shape or insufficient columns.")

    X_real, y_real = real_data[:, :-1], real_data[:, -1].astype(int)
    X_syn = syn_data[:, :-1]
    y_syn_raw = np.rint(syn_data[:, -1])

    real_classes = np.unique(y_real)
    diffs = np.abs(y_syn_raw[:, None] - real_classes)
    y_syn = real_classes[np.argmin(diffs, axis=1)].astype(int)

    scaler = StandardScaler()
    X_syn_scaled = scaler.fit_transform(X_syn)
    X_real_scaled = scaler.transform(X_real)

    label_map = {v: i for i, v in enumerate(real_classes)}
    y_syn_mapped = np.array([label_map[y] for y in y_syn])
    y_real_mapped = np.array([label_map[y] for y in y_real])

    results = {}

    print("\n[Logistic Regression]")
    lr = LogisticRegression(max_iter=200, solver='lbfgs', multi_class='auto', random_state=42)
    lr.fit(X_syn_scaled, y_syn)
    scores, avg = perform_cv_verbose(lr, X_real_scaled, y_real)
    results['LogisticRegression'] = {'folds': scores, 'accuracy': avg, 'model': lr}

    print("\n[MLP Classifier]")
    mlp = MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=300, early_stopping=True, random_state=42)
    mlp.fit(X_syn_scaled, y_syn)
    scores, avg = perform_cv_verbose(mlp, X_real_scaled, y_real)
    results['MLP'] = {'folds': scores, 'accuracy': avg, 'model': mlp}

    print("\n[XGBoost]")
    xgb_clf = xgb.XGBClassifier(
        objective='multi:softprob' if len(real_classes) > 2 else 'binary:logistic',
        num_class=len(real_classes) if len(real_classes) > 2 else None,
        use_label_encoder=False,
        eval_metric='mlogloss' if len(real_classes) > 2 else 'logloss',
        random_state=42
    )
    xgb_clf.fit(X_syn_scaled, y_syn_mapped)
    scores, avg = perform_cv_verbose(xgb_clf, X_real_scaled, y_real_mapped)
    results['XGBoost'] = {'folds': scores, 'accuracy': avg, 'model': xgb_clf}

    print("\n[Random Forest]")
    rf = RandomForestClassifier(n_estimators=150, max_depth=20, min_samples_leaf=3, random_state=42, n_jobs=-1)
    rf.fit(X_syn_scaled, y_syn)
    scores, avg = perform_cv_verbose(rf, X_real_scaled, y_real)
    results['RandomForest'] = {'folds': scores, 'accuracy': avg, 'model': rf}

    return results


# -------------------------------
# Hyperparameter parsing and script entry point
# -------------------------------
def parse_args():
    parser = argparse.ArgumentParser(description="TabDDPM Training with ComplexMLP and TSTR Evaluation")

    # --- Diffusion hyperparameters ---
    parser.add_argument("--T", type=int, default=1000, help="Total diffusion timesteps")
    parser.add_argument("--beta_start", type=float, default=1e-4, help="Starting beta value for noise schedule")
    parser.add_argument("--beta_end", type=float, default=0.02, help="Ending beta value for noise schedule")

    # --- Dataset hyperparameters ---
    # Made data_file required
    parser.add_argument("--data_file", type=str, required=True,
                        help="Path to the real dataset file (whitespace or comma-delimited, numeric)")

    # --- Training hyperparameters for TabDDPM ---
    parser.add_argument("--epochs", type=int, default=30, help="Number of training epochs for TabDDPM") # Increased default
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size for TabDDPM training") # Increased default
    parser.add_argument("--learning_rate", type=float, default=2e-4, help="Learning rate for Adam optimizer") # Adjusted default

    # --- Network architecture hyperparameters (ComplexMLP) ---
    parser.add_argument("--hidden_dim", type=int, default=256, help="Hidden layer size for the MLP")
    parser.add_argument("--num_residual_blocks", type=int, default=4, help="Number of residual blocks in the MLP")
    parser.add_argument("--time_emb_dim", type=int, default=128, help="Dimension for the sinusoidal time embedding")

    # --- Sampling hyperparameter ---
    parser.add_argument("--num_syn_samples", type=int, default=None,
                        help="Number of synthetic samples to generate (defaults to size of real dataset)")
    parser.add_argument("--output_file", type=str, default="synthetic_data.csv",
                        help="Filename to save the generated synthetic data")
    # Argument to control TSTR evaluation
    parser.add_argument("--skip_tstr", action='store_true', help="Skip the TSTR evaluation step")


    return parser.parse_args()

# -------------------------------
import numpy as np
from scipy.spatial.distance import jensenshannon
from scipy.stats import wasserstein_distance

def evaluate_jsd_wd(real_data, synthetic_data):
    """
    Computes average Jensen-Shannon Divergence (JSD) and Wasserstein Distance (WD)
    between real and synthetic datasets across all shared numeric columns.
    
    Args:
        real_data (np.ndarray): Real dataset as a NumPy array.
        synthetic_data (np.ndarray): Synthetic dataset as a NumPy array.
        
    Returns:
        dict: Dictionary with average JSD and WD across numeric columns,
              and per-column JSD/WD.
    """
    if real_data.shape[1] != synthetic_data.shape[1]:
        raise ValueError("Datasets must have the same number of columns.")

    jsd_scores = []
    wd_scores = []
    column_stats = {}

    for col in range(real_data.shape[1]):
        real_col = real_data[:, col]
        syn_col = synthetic_data[:, col]

        if not np.issubdtype(real_col.dtype, np.number) or not np.issubdtype(syn_col.dtype, np.number):
            continue  # Skip non-numeric columns

        # Bin data for JSD
        combined = np.concatenate([real_col, syn_col])
        bins = np.histogram_bin_edges(combined, bins='auto')
        real_hist, _ = np.histogram(real_col, bins=bins, density=True)
        syn_hist, _ = np.histogram(syn_col, bins=bins, density=True)

        # Avoid division by zero or log(0)
        real_hist += 1e-12
        syn_hist += 1e-12

        real_hist /= real_hist.sum()
        syn_hist /= syn_hist.sum()

        jsd = jensenshannon(real_hist, syn_hist, base=2)
        wd = wasserstein_distance(real_col, syn_col)

        jsd_scores.append(jsd)
        wd_scores.append(wd)
        column_stats[f"col_{col}"] = {"JSD": jsd, "WD": wd}

    avg_jsd = np.mean(jsd_scores) if jsd_scores else None
    avg_wd = np.mean(wd_scores) if wd_scores else None

    return {
        "average_jsd": avg_jsd,
        "average_wd": avg_wd,
        "per_column": column_stats
    }

def main():
    import torch
    import numpy as np

    hparams = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    print("=============================================")
    print("        TabDDPM & TSTR Evaluation Script      ")
    print("=============================================")
    print(f"Using device: {device}")
    print("\nHyperparameters:")
    for key, value in vars(hparams).items():
        print(f"  {key}: {value}")
    print("---------------------------------------------")

    # Load dataset
    try:
        data_np = load_dataset(hparams.data_file)
    except FileNotFoundError:
        print(f"Error: Dataset file '{hparams.data_file}' not found. Exiting.")
        return
    except Exception as e:
        print(f"Error loading dataset: {e}. Exiting.")
        return

    if data_np is None or data_np.size == 0:
        print("Error: Loaded dataset is empty. Exiting.")
        return
    if data_np.ndim != 2 or data_np.shape[1] < 2:
        print(f"Error: Dataset must have at least 2 columns. Got shape {data_np.shape}. Exiting.")
        return

    # Sample size setup
    num_real_samples, input_dim = data_np.shape
    num_syn_samples = hparams.num_syn_samples or num_real_samples//2
    print(f"\nReal dataset shape: {data_np.shape}")
    print(f"Will generate {num_syn_samples} synthetic samples.")
    print("---------------------------------------------")

    # Convert to tensor
    data_tensor = torch.tensor(data_np, dtype=torch.float, device='cpu')

    # Train diffusion model
    print("\nStarting Diffusion Model Training...")
    model, T, betas, alphas, alpha_bar = train_tabddpm(data_tensor, hparams, device)
    print("---------------------------------------------")

    # Generate synthetic data
    print("\nStarting Synthetic Data Generation...")
    sampling_batch_size = min(hparams.batch_size * 2, 1024)
    synthetic_tensor = sample_tabddpm(
        model, T, betas, alphas, alpha_bar,
        num_syn_samples, input_dim, device,
        batch_size=sampling_batch_size
    )
    synthetic_data = synthetic_tensor.cpu().numpy()

    # Round target column
    if synthetic_data.shape[1] > 0:
        synthetic_data[:, -1] = np.rint(synthetic_data[:, -1])
        print("Post-processing synthetic data (rounding target column)...")
        print(f"  Unique target values after rounding: {np.unique(synthetic_data[:, -1])}")
    else:
        print("Warning: Synthetic data has no columns. Skipping rounding.")

    # Save synthetic data
    try:
        np.savetxt(hparams.output_file, synthetic_data, delimiter=",", fmt="%.6g")
        print(f"Synthetic dataset saved to {hparams.output_file}")
    except Exception as e:
        print(f"Error saving synthetic data: {e}")
    print("---------------------------------------------")

    # Run TSTR evaluation
    if not hparams.skip_tstr:
        if synthetic_data.shape[0] > 0 and data_np.shape[0] > 0:
            print("\nRunning TSTR Evaluation (3-Fold CV)...")
            tstr_results = tstr_evaluation_cv_full(synthetic_data, data_np)
            print("\nFinal TSTR Accuracies Summary:")
            print("---------------------------------------------")
            for model_name, result in tstr_results.items():
                acc = result.get('accuracy')
                if acc is not None:
                    print(f"  {model_name}: {acc:.4f}")
                else:
                    print(f"  {model_name}: Error during evaluation ({result.get('error', 'Unknown error')})")
            print("---------------------------------------------")
        else:
            print("Skipping TSTR evaluation: synthetic or real data is empty.")
    else:
        print("Skipping TSTR evaluation (--skip_tstr flag set).")

    # Evaluate JSD and WD
    print("\nEvaluating JSD and WD...")
    jsd_wd_results = evaluate_jsd_wd(data_np, synthetic_data)
    print("Average JSD:", jsd_wd_results["average_jsd"])
    print("Average WD:", jsd_wd_results["average_wd"])

    print("\nScript finished.")
    print("=============================================")


if __name__ == "__main__":
    main()